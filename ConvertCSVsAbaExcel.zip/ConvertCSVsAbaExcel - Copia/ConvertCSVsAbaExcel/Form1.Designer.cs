﻿
namespace ConvertCSVsAbaExcel
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtCaminhoCSVs = new System.Windows.Forms.TextBox();
            this.txtCaminhoExcel = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnConverter = new System.Windows.Forms.Button();
            this.txtNomeExcel = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Caminho CSVs:";
            // 
            // txtCaminhoCSVs
            // 
            this.txtCaminhoCSVs.Location = new System.Drawing.Point(149, 10);
            this.txtCaminhoCSVs.Name = "txtCaminhoCSVs";
            this.txtCaminhoCSVs.Size = new System.Drawing.Size(380, 23);
            this.txtCaminhoCSVs.TabIndex = 1;
            // 
            // txtCaminhoExcel
            // 
            this.txtCaminhoExcel.Location = new System.Drawing.Point(149, 53);
            this.txtCaminhoExcel.Name = "txtCaminhoExcel";
            this.txtCaminhoExcel.Size = new System.Drawing.Size(380, 23);
            this.txtCaminhoExcel.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Caminho Excel:";
            // 
            // btnConverter
            // 
            this.btnConverter.Location = new System.Drawing.Point(30, 159);
            this.btnConverter.Name = "btnConverter";
            this.btnConverter.Size = new System.Drawing.Size(499, 23);
            this.btnConverter.TabIndex = 4;
            this.btnConverter.Text = "Converter";
            this.btnConverter.UseVisualStyleBackColor = true;
            this.btnConverter.Click += new System.EventHandler(this.btnConverter_Click);
            // 
            // txtNomeExcel
            // 
            this.txtNomeExcel.Location = new System.Drawing.Point(149, 92);
            this.txtNomeExcel.Name = "txtNomeExcel";
            this.txtNomeExcel.Size = new System.Drawing.Size(380, 23);
            this.txtNomeExcel.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Nome Excel:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 191);
            this.Controls.Add(this.txtNomeExcel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnConverter);
            this.Controls.Add(this.txtCaminhoExcel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtCaminhoCSVs);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCaminhoCSVs;
        private System.Windows.Forms.TextBox txtCaminhoExcel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnConverter;
        private System.Windows.Forms.TextBox txtNomeExcel;
        private System.Windows.Forms.Label label3;
    }
}

