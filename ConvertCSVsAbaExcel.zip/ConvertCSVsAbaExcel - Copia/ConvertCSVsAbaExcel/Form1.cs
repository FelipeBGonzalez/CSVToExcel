﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvertCSVsAbaExcel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConverter_Click(object sender, EventArgs e)
        {
            string caminhoExcel = txtCaminhoExcel.Text + @"\" + txtNomeExcel.Text + ".xlsx";

            DirectoryInfo Dir = new DirectoryInfo(txtCaminhoCSVs.Text);

            ExcelPackage package = new ExcelPackage(new FileInfo(caminhoExcel));
            FileInfo[] Files = Dir.GetFiles("*", SearchOption.AllDirectories);
            var format = new ExcelTextFormat();
            format.Delimiter = ';';
            format.EOL = "\n";
            bool firstRowIsHeader = true;
            foreach (FileInfo file in Files)
            {                             
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(file.Name);
                worksheet.Cells["A1"].LoadFromText(file, format, OfficeOpenXml.Table.TableStyles.Medium27, firstRowIsHeader);
            }
            package.Save();
        }
    }
}
